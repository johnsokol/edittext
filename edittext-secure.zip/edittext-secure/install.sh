#!/bin/bash
#
# install.sh - edittext Installation Script
# Sets up proper permissions and directories
#

set -euo pipefail

# Configuration - adjust these for your system
INSTALL_DIR="/htdocs/edittext"
CGI_DIR="/cgi-bin"
WEB_USER="www-data"  # Apache/nginx user (adjust for your system)

echo "=========================================="
echo "  edittext Secure Installation"
echo "=========================================="
echo

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (sudo ./install.sh)"
    exit 1
fi

# Create directories
echo "[1/6] Creating directories..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$CGI_DIR"

# Copy files
echo "[2/6] Copying files..."
cp edittext.cgi "$CGI_DIR/"
cp makeindex "$INSTALL_DIR/"

# Initialize data files
echo "[3/6] Initializing data files..."
echo "0" > "$INSTALL_DIR/count"
touch "$INSTALL_DIR/access.log"
touch "$INSTALL_DIR/makeindex.log"

# Create a sample first post (protected source view)
cat > "$INSTALL_DIR/FILE1.html" << 'EOF'
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Welcome to edittext</title>
<!--
DATALINE subject=Welcome+to+edittext&limitedtextarea=This+is+the+secure+version+of+edittext.&filename=1
LISTINGDATA <a href="/edittext/FILE1.html">Welcome to edittext</a>, &nbsp; <a href="/cgi-bin/edittext.cgi?name=1">edit</a>
-->
</head>
<body>
<div style="max-width:800px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;">
<h1>Welcome to edittext</h1>
<p>This is the secure version of edittext - a complete web CMS in bash.</p>
<p><a href="/edittext/">Back to listings</a></p>
</div>
</body>
</html>
EOF
echo "1" > "$INSTALL_DIR/count"

# Set permissions
echo "[4/6] Setting permissions..."
chmod 755 "$CGI_DIR/edittext.cgi"
chmod 755 "$INSTALL_DIR/makeindex"
chmod 644 "$INSTALL_DIR/count"
chmod 644 "$INSTALL_DIR/access.log"
chmod 644 "$INSTALL_DIR/makeindex.log"
chmod 644 "$INSTALL_DIR/FILE1.html"

# Set ownership
echo "[5/6] Setting ownership..."
chown -R "$WEB_USER:$WEB_USER" "$INSTALL_DIR"
chown "$WEB_USER:$WEB_USER" "$CGI_DIR/edittext.cgi"

# Build initial index
echo "[6/6] Building initial index..."
"$INSTALL_DIR/makeindex"

echo
echo "=========================================="
echo "  Installation Complete!"
echo "=========================================="
echo
echo "Files installed:"
echo "  CGI:    $CGI_DIR/edittext.cgi"
echo "  Data:   $INSTALL_DIR/"
echo
echo "Access your site at:"
echo "  http://yourserver/cgi-bin/edittext.cgi"
echo "  http://yourserver/edittext/"
echo
echo "Security features enabled:"
echo "  ✓ Input sanitization (XSS prevention)"
echo "  ✓ HTML entity encoding"
echo "  ✓ CSRF token protection"
echo "  ✓ File locking (concurrent access)"
echo "  ✓ Filename validation"
echo "  ✓ Content length limits"
echo "  ✓ Access logging"
echo
echo "Recommended: Configure your web server to:"
echo "  - Enable HTTPS"
echo "  - Set proper CGI execution"
echo "  - Restrict access if needed (.htaccess)"
echo
