# edittext - Security Hardened Version

A complete web CMS in bash, now with security fixes.

**Original Author:** John Sokol (circa 2000s)  
**Security Hardening:** 2025

## What Is This?

edittext is a fully functional web-based content management system implemented entirely in Bash shell scripting. It demonstrates that sophisticated web applications can be built with minimal tools - just bash, and standard Unix utilities.

This security-hardened version adds:

- ✅ **Input Sanitization** - All user input is HTML-encoded to prevent XSS
- ✅ **CSRF Protection** - Token-based protection against cross-site request forgery
- ✅ **File Locking** - Prevents race conditions with concurrent edits
- ✅ **Filename Validation** - Only numeric IDs accepted, prevents path traversal
- ✅ **Content Limits** - Maximum lengths enforced for subject and content
- ✅ **Access Logging** - Audit trail of all operations
- ✅ **Strict Mode** - `set -euo pipefail` catches errors early

## Files

```
edittext-secure/
├── edittext.cgi    # Main CGI script (~300 lines)
├── makeindex       # Index rebuilder (~50 lines)
├── install.sh      # Installation script
└── README.md       # This file
```

## Installation

```bash
# Clone or download files
cd edittext-secure

# Run installer as root
sudo ./install.sh
```

The installer will:
1. Create `/htdocs/edittext/` for data files
2. Install CGI script to `/cgi-bin/`
3. Set proper permissions
4. Create initial index

## Security Features Explained

### 1. Input Sanitization (XSS Prevention)

```bash
# All output is HTML-encoded
html_encode() {
    local str="$1"
    str="${str//&/&amp;}"
    str="${str//</&lt;}"
    str="${str//>/&gt;}"
    str="${str//\"/&quot;}"
    str="${str//\'/&#39;}"
    printf '%s' "$str"
}
```

**Before:** User could submit `<script>alert('xss')</script>`  
**After:** Displayed as literal text, not executed

### 2. CSRF Protection

Each form includes a token:
```html
<input type="hidden" name="csrf_token" value="a1b2c3d4...">
```

Token is SHA256 hash of:
- Server secret
- Client IP
- Current hour

Posts without valid token are rejected.

### 3. File Locking

```bash
acquire_lock() {
    exec 200>"$LOCKFILE"
    flock -w 5 200 || exit 1
}
```

Prevents corruption when multiple users edit simultaneously.

### 4. Filename Validation

```bash
validate_filename_num() {
    local num="$1"
    # Must be numeric only
    if [[ ! "$num" =~ ^[0-9]+$ ]]; then
        exit 1
    fi
    # Must be in valid range
    if [ "$num" -gt 99999 ] || [ "$num" -lt 1 ]; then
        exit 1
    fi
}
```

Prevents path traversal attacks like `?name=../../../etc/passwd`

### 5. Access Logging

All operations logged to `access.log`:
```
2025-12-09 10:30:45|192.168.1.100|POST_SAVE|file=FILE42.html subject='My Post Title'
2025-12-09 10:31:02|192.168.1.101|GET_EDIT|file=FILE42.html
2025-12-09 10:32:15|192.168.1.102|CSRF_FAIL|Invalid token from 192.168.1.102
```

## Configuration

Edit the top of `edittext.cgi`:

```bash
BASEDIR="/htdocs/edittext"      # Data directory
WORKDIR="/edittext"             # URL path to data
THISCGI="/cgi-bin/edittext.cgi" # URL path to CGI
MAX_SUBJECT_LEN=100             # Max subject length
MAX_CONTENT_LEN=10000           # Max content length
MAX_FILENAME_NUM=99999          # Max post ID
```

## Web Server Configuration

### Apache

```apache
# Enable CGI
ScriptAlias /cgi-bin/ /usr/lib/cgi-bin/
<Directory "/usr/lib/cgi-bin">
    AllowOverride None
    Options +ExecCGI
    Require all granted
</Directory>

# Serve static files
Alias /edittext/ /htdocs/edittext/
<Directory "/htdocs/edittext">
    Options Indexes
    Require all granted
</Directory>
```

### nginx (with fcgiwrap)

```nginx
location /cgi-bin/ {
    gzip off;
    root /usr/lib;
    fastcgi_pass unix:/var/run/fcgiwrap.socket;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME /usr/lib$fastcgi_script_name;
}

location /edittext/ {
    alias /htdocs/edittext/;
    autoindex on;
}
```

## Adding Authentication

For basic password protection, add `.htaccess`:

```apache
AuthType Basic
AuthName "edittext"
AuthUserFile /etc/htpasswd-edittext
Require valid-user
```

Create password file:
```bash
htpasswd -c /etc/htpasswd-edittext admin
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    edittext Architecture                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Browser ──GET/POST──→ edittext.cgi                         │
│                              │                               │
│            ┌─────────────────┴─────────────────┐            │
│            │                                    │            │
│       [GET request]                      [POST request]      │
│            │                                    │            │
│     ┌──────┴──────┐                    ┌───────┴───────┐    │
│     │ ?name=N     │ no params          │ Parse form    │    │
│     │ Load FILE   │ New post           │ Validate CSRF │    │
│     │ Parse DATA  │ Increment counter  │ Sanitize input│    │
│     └──────┬──────┘                    └───────┬───────┘    │
│            │                                    │            │
│            └─────────────┬─────────────────────┘            │
│                          │                                   │
│                   Render HTML                                │
│                          │                                   │
│            ┌─────────────┴─────────────┐                    │
│            │                           │                     │
│     [Editor Form]               [Save FILE{N}.html]         │
│                                        │                     │
│                                  Run makeindex               │
│                                        │                     │
│                                 Rebuild index.html           │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Self-Documenting Files

Each post contains its own edit data in HTML comments:

```html
<!--
DATALINE subject=Hello+World&limitedtextarea=Content+here&filename=42
LISTINGDATA <a href="/edittext/FILE42.html">Hello World</a>, <a href="...">edit</a>
-->
```

- **DATALINE** - Original form data for re-editing
- **LISTINGDATA** - Pre-built HTML for the index page

This elegant design means:
- No database required
- Each file is self-contained
- Index can be rebuilt from files anytime

## Comparison: Original vs Secure

| Feature | Original | Secure |
|---------|----------|--------|
| XSS Protection | ❌ None | ✅ HTML encoding |
| CSRF Protection | ❌ None | ✅ Token validation |
| File Locking | ❌ None | ✅ flock() |
| Input Validation | ❌ Minimal | ✅ Type + length |
| Path Traversal | ❌ Vulnerable | ✅ Numeric only |
| Error Handling | ❌ Silent | ✅ Strict mode |
| Logging | ❌ None | ✅ Full audit trail |
| HTTPS | ❌ Optional | ✅ Recommended |

## Limitations

Even with security fixes, this remains a simple system:

- **No user authentication** - Add via .htaccess or extend CGI
- **No rich text** - Plain text only (by design)
- **No image uploads** - Text content only
- **Single server** - Not distributed (but files could sync)
- **No versioning** - Edits overwrite (could add git integration)

## Philosophy

> "A complete application platform where all the code is visible, anyone can debug it, and the data format is self-documenting."

This security-hardened version maintains the original spirit:
- Still ~350 lines total
- Still pure bash (no external languages)
- Still human-readable
- Still self-documenting files

## License

GNU General Public License v3.0

## Links

- Original repo: https://github.com/johnsokol/edittext
- Author: http://www.johnsokol.com
